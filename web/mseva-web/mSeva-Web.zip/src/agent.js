import superagentPromise from 'superagent-promise';
import _superagent from 'superagent';

const superagent = superagentPromise(_superagent, global.Promise);

const API_ROOT = window.location.origin;

const encode = encodeURIComponent;
const responseBody = res => res.body;

let token = null;
let userId = null;
let type = null;
let jurisdiction_id = 6;
let tenantId = "ap.public";

let authorization = "Basic ZWdvdi11c2VyLWNsaWVudDplZ292LXVzZXItc2VjcmV0";

const formatDate = function() {
    var date = new Date();
    return (date.getDate() + "-" + ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : (date.getMonth() + 1)) + "-" + date.getFullYear() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
}

const getTenantId = function() {
    return localStorage.getItem("tenantId") || "ap.public";
}

const createRequestInfo = (action) => {
    let json = {
        "api_id": "org.egov.pgr",
        "ver": "1.0",
        "ts": formatDate(),
        "action": action,
        "did": "4354648646",
        "key": "xyz",
        "msg_id": "654654",
        "requester_id": "61",
        "authToken": token || ""
    };
    return json;
}

const createHeaderInfo = (action) => {
    let json = {
        "api_id": "org.egov.pgr",
        "ver": "1.0",
        "ts": formatDate(),
        "action": action,
        "did": "4354648646",
        "key": "xyz",
        "msg_id": "654654",
        "requester_id": "61",
        "authorization": authorization,
        "auth_token": token || ""
    };
    
    return json;
}

const tokenPlugin = authRequired => {
    return createHeaderInfo("option");
}

const requests = {
    del: (url, authRequired) =>
        superagent.del(`${API_ROOT}${url}`).set(tokenPlugin(authRequired)).then(responseBody),
    get: (url, authRequired) =>
        superagent.get(`${API_ROOT}${url}`).set(tokenPlugin(authRequired)).then(responseBody),
    put: (url, body, authRequired) =>
        superagent.put(`${API_ROOT}${url}`, body).set(tokenPlugin(authRequired)).then(responseBody),
    post: (url, body, authRequired) => 
        superagent.post(`${API_ROOT}${url}`, body).set(tokenPlugin(authRequired)).then(responseBody),
    upload: (url, formData, authRequired) =>
      superagent.post(`${API_ROOT}${url}`).send(formData).then(responseBody)
};

const Auth = {
    current: () =>
        requests.get('/user'),
    login: (username, password) => requests.post(`/user/_login?tenantId=${getTenantId()}&username=${username}&password=${password}&grant_type=password&scope=read`),
    register: (User) =>
        requests.post('/user/users/_create', {
            RequestInfo: createRequestInfo("POST"),
            User
        }),
    save: user =>
        requests.put('/user', {
            user
        }),
    getOtp: (mobileNumber) =>
        requests.post(`/user-otp/v1/_send`, {
            otp: {
                tenantId: getTenantId(),
                mobileNumber
            },
            RequestInfo: createRequestInfo("POST")
        }),
    validateOtp: (identity, otp) =>
        requests.post(`/otp/v1/_validate`, {
            RequestInfo: createRequestInfo("POST"),
            otp: {
                tenantId: getTenantId(),
                otp,
                identity
            }
        })
};

const labels = {
    getLabels: () => 
        requests.get(`/localization/messages?tenantId=${getTenantId()}&locale=en_IN`)
}

const complaints = {
    getComplaints:()=> 
        requests.get(`/pgr/seva?jurisdiction_id=${jurisdiction_id}&user_id=${userId}`),
    getAllComplaints:()=>
        requests.get(`/pgr/seva?jurisdiction_id=${jurisdiction_id}&status=COMPLETED`),
    postComplaint: (ServiceRequest) => 
        requests.post(`/pgr/seva?jurisdiction_id=ap.public`, {
            RequestInfo: createRequestInfo("POST"),
            ServiceRequest
        }, true),
    updateComplaint: (ServiceRequest) => 
        requests.put(`/pgr/seva`, {
            RequestInfo: createRequestInfo("PUT"),
            ServiceRequest
        }, true),
    uploadImage: (formData) =>
        requests.upload(`/filestore/v1/files`, formData, true),
    getCategories: () =>
        requests.get(`/pgr/complaintTypeCategories?tenantId=${getTenantId()}`),
    getComplaintTypes: (category) =>
        requests.get(`/pgr/services?type=category&categoryId=${category}&tenantId=${getTenantId()}`),
    getAllComplaintTypes: () =>
        requests.get(`/pgr/services?type=all&tenantId=${getTenantId()}`),
    getTrendingComplaintTypes: () =>
        requests.get(`/pgr/services?type=frequency&count=5&tenantId=${getTenantId()}`),
    getComplaintDetails: (service_request_id) =>
        requests.get(`/pgr/seva?jurisdiction_id=${jurisdiction_id}&service_request_id=${service_request_id}`),
    getComplaintHistory: (worklowId) =>
        requests.get(`/workflow/history?tenantId=${getTenantId()}&workflowId=${worklowId}`),
    getFiles: (service_request_id) =>
        requests.get(`/filestore/v1/files/tag?tag=${service_request_id}`, true),
    getFile: (url) =>
        requests.get(url),
    getLocationByName: (name) =>
        requests.get(`/v1/location/boundarys/getLocationByLocationName?locationName=${name}`),
    getLocationById: (id) =>
        requests.get(`/v1/location/boundarys?boundary=${id}`, true)
}



export default {
    Auth,
    setToken: _token => {
        token = _token;
    },
    setUserId: _userId => {
        userId = _userId
    },
    setType: _type => {
        type = _type
    },
    complaints,
    labels,
    getTenantId
};
