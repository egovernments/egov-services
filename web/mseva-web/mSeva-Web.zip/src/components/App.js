import agent from '../agent';
import React, {Component} from 'react';
import {connect} from 'react-redux';
import ListErrors from './common/ListErrors';
import Spinner from 'react-spinkit';
import {OpenModal, CloseModal} from '../utils/modal';
import {titleCase} from '../utils/utilMethods';
import $ from 'jquery';
import BlockUi from 'react-block-ui';
import { Loader, Types } from 'react-loaders';
import 'react-block-ui/style.css';
import 'loaders.css/loaders.min.css';

const mapStateToProps = state => ({
    labels: state.labels,
    appLoaded: state.common.appLoaded,
    appName: state.common.appName,
    currentUser: state.common.currentUser,
    redirectTo: state.common.redirectTo,
    auth: {
        ...state.auth
    },
    pleaseWait: state.common.pleaseWait
});

// this.props.appLoaded

const mapDispatchToProps = dispatch => ({
    onLoad: (payload, token) => dispatch({type: 'APP_LOAD', payload, token, skipTracking: true}),
    onRedirect: () => dispatch({type: 'REDIRECT'}),
    setLabels: payload => dispatch({type: 'LABELS', payload}),
    onUpdateAuth: (value, key) => dispatch({type: 'UPDATE_FIELD_AUTH', key, value}),
    onLogin: (username, password) => {
        dispatch({
            type: 'LOGIN',
            payload: agent.Auth.login(username, password)
        })
    },
    updateError: (error) =>
        dispatch({
            type: 'UPDATE_ERROR',
            error
        }),
    setPleaseWait: (pleaseWait) =>
        dispatch({
            type: 'PLEASE_WAIT',
            pleaseWait
        })
});

class App extends Component {
    constructor(props) {
        super(props);
        this.getOtp = this.getOtp.bind(this);
        this.validateOtp = this.validateOtp.bind(this);
        this.callLogin = this.callLogin.bind(this);
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.redirectTo) {
            this.context.router.replace(nextProps.redirectTo);
            this.props.onRedirect();
        }
    }

    componentWillMount() {
        this.props.setLabels(agent.labels.getLabels());
        const token = window.localStorage.getItem('jwt');
        const userId = window.localStorage.getItem('userId');
        const type = window.localStorage.getItem('type');

        let currentUser = window.localStorage.getItem('currentUser');

        if(currentUser) {
            currentUser = JSON.parse(currentUser);
        }

        if (token) {
            agent.setToken(token);
            agent.setUserId(userId);
            agent.setType(type);
        }

        this.props.onLoad(!currentUser
            ? agent.Auth.login((this.props.auth.userName || "9999999999"), (this.props.auth.password || "demo"))
            : {UserRequest: currentUser}, token);
    }

    getOtp(e) {
        e.preventDefault();
        this.props.updateError("");
        if(!/[0-9]{10}/.test(this.props.auth.mobileNumber)) {
            this.props.updateError(this.props.labels["core.lbl.enter.mobilenumber"])
        } else {
             this.props.setPleaseWait(true);
             agent.Auth.getOtp(this.props.auth.mobileNumber).then(
                res => {
                    CloseModal("signupModal");
                    OpenModal("otpModal");
                    this.props.setPleaseWait(false);
                },
                error => {
                    //Handle error
                    console.log(error);
                    this.props.updateError(error.Error ? error.Error.message : this.props.labels["core.error.opt.generation"])
                    this.props.setPleaseWait(false);
               }
            )
        }
    }

    validateOtp(e) {
        e.preventDefault();
        this.props.updateError("");
        if(this.props.auth.newPassword !== this.props.auth.confirmPassword) {
            //Handle password mismatch
            this.props.updateError(this.props.labels["core.error.password.confirmpassword.same"]);
        } else {
            this.props.setPleaseWait(true);
            agent.Auth.validateOtp(this.props.auth.mobileNumber, this.props.auth.otp).then(
                res => {
                    let User = {
                        "userName": this.props.auth.mobileNumber,
                        "password": this.props.auth.newPassword,
                        "name": this.props.auth.fullName,
                        "gender": "MALE",
                        "mobileNumber": this.props.auth.mobileNumber,
                        "emailId": this.props.auth.emailId || "demo@egov.coms",
                        "active": true,
                        "type": "CITIZEN",
                        "otpReference": res.otp.UUID,
                        "tenantId": "ap.public"
                    };
                    //Create user and login
                    agent.Auth.register(User)
                    .then(
                        res => {
                            this.props.setPleaseWait(false);
                            this.props.onUpdateAuth(this.props.auth.mobileNumber, "userName");
                            this.props.onUpdateAuth(this.props.auth.newPassword, "password");
                            this.props.onLogin(this.props.auth.mobileNumber, this.props.auth.newPassword);
                            $('.toast').fadeIn(400).delay(4000).fadeOut(400);
                            //Get auth token and close modal
                            CloseModal("otpModal");
                            //Clear sign up data
                            this.props.onUpdateAuth("", "mobileNumber");
                            this.props.onUpdateAuth("", "fullName");
                            this.props.onUpdateAuth("", "emailId");
                            this.props.onUpdateAuth("", "otp");
                            this.props.onUpdateAuth("", "newPassword");
                            this.props.onUpdateAuth("", "confirmPassword");
                        },
                        error => {
                            //Handle error
                            console.log(error);
                            this.props.setPleaseWait(false);
                            this.props.updateError(error ? error + "" : "Oops! Looks like something went wrong. Please try again after sometime.")
                        }
                    )
                },
                error => {
                    //Handle error
                    console.log(error);
                    this.props.setPleaseWait(false);
                    this.props.updateError(error ? error + "" : "Oops! Looks like something went wrong. Please try again after sometime.")
                }
            )
        }
    }

    callLogin (e, username, password) {
        e.preventDefault();
        this.props.updateError("");
        this.props.onLogin(username, password);
    }

    render() {
        let {getOtp, validateOtp, callLogin} = this;
        let {onUpdateAuth, onLogin, pleaseWait, labels} = this.props;
        let {username, password, inProgress, fullName, mobileNumber, emailId, confirmPassword, newPassword, otp} = this.props.auth;
        
        return (
            <div>
              {/*<BlockUi tag="div" blocking={inProgress} loader={<Loader active type="line-scale-pulse-out-rapid" color="#51bad9"/>}>*/}
                {this.props.children}
                <div className="modal fade login-modal" id="loginModal" role="dialog">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h2>{labels["core.lbl.login"]}
                                </h2>
                                <form onSubmit={(e) => callLogin(e, username, password)}>
                                    <div className="login-input mobile">
                                        <input type="text" id="userName" placeholder={labels["core.lbl.addmobilenumber/login"]} onChange={e => onUpdateAuth(e.target.value, "username")} required/>
                                    </div>
                                    <div className="login-input password">
                                        <input type="password" id="password" placeholder={labels["core.lbl.password"]} onChange={e => onUpdateAuth(e.target.value, "password")} required/>
                                    </div>
                                    <div className="text-right">
                                        <a href="#" data-toggle="modal" data-target="#forgotModal" data-dismiss="modal">{labels["core.lbl.forgot.password"]}
                                        </a>
                                    </div>
                                    <ListErrors errors={this.props.auth.errors}/>
                                    <button type="submit" className="btn btn-primary" disabled={inProgress}>{labels["core.lbl.login"]}</button>
                                </form>
                                <p>New to mSeva ?
                                    <a href="#" data-toggle="modal" data-target="#signupModal" data-dismiss="modal"> {labels["core.lbl.signup"]}
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="modal fade login-modal" id="signupModal" role="dialog">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h2>{labels["core.lbl.signup"]}
                                </h2>
                                <form onSubmit={(e) => {getOtp(e)}}>
                                    <div className="login-input user">
                                        <input type="text" id="" placeholder={labels["core.lbl.fullname"]} onChange={e => onUpdateAuth(e.target.value, "fullName")} value={fullName} required/>
                                    </div>
                                    <div className="login-input mobile">
                                        <input type="text" id="" placeholder={labels["core.lbl.mobilenumber"]} onChange={e => onUpdateAuth(e.target.value, "mobileNumber")} value={mobileNumber} required/>
                                    </div>
                                    <div className="login-input email">
                                        <input type="email" id="" placeholder={labels["core.lbl.email"]} onChange={e => onUpdateAuth(e.target.value, "emailId")} value={emailId}/>
                                    </div>
                                    <ListErrors errors={this.props.auth.errors}/>
                                    <button type="submit" className="btn btn-primary" disabled={pleaseWait}>{labels["pgr.lbl.generate.otp"]}</button>
                                </form>
                                <p>Have an account? 
                                    <a href="#" data-toggle="modal" data-target="#loginModal" data-dismiss="modal"> {labels["core.lbl.login"]}
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="modal fade login-modal" id="forgotModal" role="dialog">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h2>Forgot Password
                                </h2>
                                <div className="login-input mobile">
                                    <input type="text" id="" placeholder={labels["core.lbl.mobilenumber"]}/>
                                </div>
                                <div className="login-input">
                                    <input type="text" id="" placeholder={labels["core.lbl.otp"]}/>
                                </div>
                                <div className="text-right">
                                    <a href="#">{titleCase(labels["core.msg.Resend"])} {labels["core.lbl.otp"]}
                                    </a>
                                </div>
                                <div className="login-input password">
                                    <input type="password" id="" placeholder={labels["core.lbl.new.password"]}/>
                                </div>
                                <div className="login-input password">
                                    <input type="password" id="" placeholder={labels["core.lbl.confirm.password"]}/>
                                </div>

                                <button className="btn btn-primary" disabled={pleaseWait}>{titleCase(labels["core.lbl.work.finish"])}</button>

                            </div>
                        </div>
                    </div>
                </div>

                <div className="modal fade login-modal" id="otpModal" role="dialog">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h2>{labels["core.lbl.otp"]}
                                    <span>{labels["core.msg.otp.sent.entertocreateaccount"]}</span>
                                </h2>
                                <form onSubmit={(e)=> {validateOtp(e)}}>
                                    <div className="login-input">
                                        <input type="text" id="otp" placeholder={labels["core.lbl.otp"]} onChange={e => onUpdateAuth(e.target.value, "otp")} value={otp} required/>
                                    </div>
                                    <div className="text-right" onClick={(e) => {getOtp(e)}}>
                                        <a href="#">{titleCase(labels["core.msg.Resend"])} {labels["core.lbl.otp"]}
                                        </a>
                                    </div>
                                    <div className="login-input password">
                                        <input type="password" id="newPasd" placeholder={labels["core.lbl.password"]} onChange={e => onUpdateAuth(e.target.value, "newPassword")} value={newPassword} required/>
                                    </div>
                                    <div className="login-input password">
                                        <input type="password" id="cnfrmPasd" placeholder={labels["core.lbl.confirm.password"]} onChange={e => onUpdateAuth(e.target.value, "confirmPassword")} value={confirmPassword} required/>
                                    </div>
                                    <ListErrors errors={this.props.auth.errors}/>
                                    
                                    <button type="submit" className="btn btn-primary" disabled={pleaseWait}>{labels["core.msg.account.create"]}</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
              {/*</BlockUi>*/}
            </div>
        );
    }
}

App.contextTypes = {
    router: React.PropTypes.object.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
