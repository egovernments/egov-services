import React, { Component } from 'react';
import {connect} from 'react-redux';

const mapStateToProps = state => ({
    labels: state.labels
});


const mapDispatchToProps = dispatch => ({
  
});

class Footer extends Component {
  render() {
    const {labels} = this.props;
    return (
      <div className="footer">
          <p>{labels["core.lbl.page.footer"]}</p>
      </div>
    );
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(Footer);
