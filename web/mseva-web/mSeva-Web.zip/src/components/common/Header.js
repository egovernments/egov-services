import React, { Component } from 'react';
import logo from "../../images/logo.png";
import egovLogo from "../../images/egov_logo_ribbon.png";
import {Link} from "react-router";
import {connect} from 'react-redux';
import $ from 'jquery';
import {OpenModal, CloseModal} from '../../utils/modal'
import {hashHistory, browserHistory} from 'react-router';

// function closeModal(modalName) {
//     $(`#${modalName}`).modal('hide');
// }

const mapStateToProps = state => ({
    labels: state.labels,
    token: state.common.token,
    route: state.common.route
});


const mapDispatchToProps = dispatch => ({
  onLogout:()=> dispatch({type:"LOGOUT"}),
  setRoute:()=> dispatch({type:"SET_ROUTE", route: ""}),
  updateError: (error) =>
        dispatch({
            type: 'UPDATE_ERROR',
            error
        })
});


class Header extends Component {
  render() {
    let {token, onLogout, route, setRoute, updateError, labels}=this.props;
    // console.log(this.props);
    const showMenu=function()
    {
      if(token)
      {
        CloseModal("loginModal");
        if(route) {
          //Redirect to the route
          hashHistory.push(route);
          setRoute("");
        } 

        return (
          <ul className="header-link-mseva">
            <li style={{'float': 'left', 'marginLeft': 0}}><img src={egovLogo} alt="" width="200px" height="35px"/></li>
            <li><Link to="/main">{labels["core.lbl.home"]}</Link></li>
            <li><Link to="/filecomplaints">{labels["pgr.lbl.file.complaint"]}</Link></li>
            <li><Link to="/complaints">{labels["pgr.lbl.my.complaints"]}</Link></li>
            <li className="bdr"><a href="#" onClick={e=> onLogout()}>{labels["core.lbl.signout"]}</a></li>
            <li><img src={logo} alt=""/> {labels["core.lbl.city.kurnool"]}</li>
          </ul>
        )
      }
      else {
        return (
        <ul className="header-link-mseva">
            <li style={{'float': 'left', 'marginLeft': 0, 'paddingTop':'5px'}}><img src={egovLogo} alt="" width="200px" height="35px"/></li>
            <li><a href="#" data-toggle="modal" data-target="#loginModal" onClick={()=>{updateError("")}}>{labels["core.lbl.login"]}</a></li>
            {/*<li className="bdr"><a href="#" data-toggle="modal" data-target="#signupModal" onClick={()=>{updateError("")}}>Signup</a></li>*/}
            <li><img src={logo} alt=""/> {labels["core.lbl.city.kurnool"]}</li>
        </ul>
        )
      }
    }
    return (
      <div>
        {showMenu()}
      </div>
    );
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(Header);
