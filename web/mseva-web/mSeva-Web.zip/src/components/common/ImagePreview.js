import React, { Component } from 'react';

export default (props) => {
    let files = props.files;
    let renderImage = () =>
    {
      if(files.length) {
        let parent = document.getElementById("imgParent");
        if(!parent) return;
        parent.innerHTML = "";
        parent.setAttribute("key", "_images_");
        let html = '', counter = files.length;
        for(let i=0; i<files.length; i++) {
          let file = files[i];
          let reader = new FileReader();
          let span = document.createElement("span");
          span.className = "image-place";
          reader.onload = function(event) {
             var bool = false;
             for(var i=0; i<span.children.length; i++) {
              if(span.children[i].getAttribute("data-name") == file.name.split(".")[0]) {
                bool = true;
                break;
              }
             }
             if(!bool){
                let img = document.createElement("img");
                img.src = event.target.result;
                img.style.width = "80px";
                img.style.height = "80px";
                span.appendChild(img);
                span.setAttribute("data-name", file.name.split(".")[0]);
                parent.appendChild(span);
             }
          }
          reader.readAsDataURL(file);
        }
      } else {
        var parent = document.getElementById("imgParent");
        if(parent)
          parent.innerHTML = "<span class='image-place'><div style='width:80px;height:80px'></div></span>";
      }
    }

    return (
      <div id="imgParent" key="_images_">
        {renderImage()}
      </div>
    )
}