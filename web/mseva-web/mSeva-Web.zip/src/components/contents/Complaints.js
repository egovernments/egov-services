import React, {Component} from 'react';
import pic01 from "../../images/pic-01.jpg";
import pic02 from "../../images/pic-02.jpg";
import {Link} from 'react-router';
import {connect} from 'react-redux';
import agent from '../../agent';

const PENDING_STATUSES = ["REGISTERED"];//, "FORWARDED", "PROCESSING", "REJECTED" ,"NOTCOMPLETED", "REOPENED"
const COMPLETED_STATUSES = ["COMPLETED"];// , "WITHDRAWN", "CLOSED"
const API_ROOT = window.location.origin;
const mapStateToProps = state => ({
    labels: state.labels,
    complaintList: state.complaint.complaintList,
    images: state.complaint.images,
    auth: state.auth
});

const mapDispatchToProps = dispatch => ({
    setComplaintList: payload => dispatch({type: "ADD_COMPLAINT_LIST", payload}),
    setImages: images => dispatch({type: 'ADD_IMAGES', images}),
    setInProgress: progress => {
        if(progress) {
            dispatch({type: 'ASYNC_START'});
        } else {
            dispatch({type: 'ASYNC_END'});
        }
    }
});

class Complaints extends Component {
    componentWillMount()
    {
        this.props.setInProgress(true);
        //Get complaint list and fetch images if any
        agent.complaints.getComplaints().then(
            res => {
                //Get complaint categories
                agent.complaints.getAllComplaintTypes().then(
                    res2 => {
                        this.props.setComplaintList(res);
                        //Fetch images
                        let _images = {};
                        let counter = res.service_requests.length;

                        if(counter == 0) {
                            this.props.setInProgress(false);
                        }
                        
                        for(let i = 0; i < res.service_requests.length; i++) {
                            for(let j=0 ;j<res2.length; j++) {
                                if(res.service_requests[i].service_code == res2[j].serviceCode) {
                                    res.service_requests[i].category = res2[j].groups;
                                }
                            }
                            agent.complaints.getFiles(res.service_requests[i].service_request_id).then(
                                res1 => {
                                    if(res1.files && res1.files.length) {
                                        let _files = res1.files.map((item) => {
                                            return item.url;
                                        });
                                        _images[res.service_requests[i].service_request_id] = _files;
                                    }

                                    counter--;
                                    if(counter == 0) {
                                        this.props.setInProgress(false);
                                        this.props.setImages(_images);
                                    }
                                },
                                error => {
                                    this.props.setInProgress(false);
                                    //Handle error
                                    console.log(error);
                                }
                            )
                        }
                    },
                    error => {
                         this.props.setInProgress(false);
                         //Handle error
                         console.log(error);
                    }
                )
            },
            error => {
                this.props.setInProgress(false);
                //Handle error
                console.log(error);
            }
        )
    };

    render() {
        let {complaintList, images, labels} = this.props;
        const formatDate = (date) => {
             return date ? date.split(" ")[0] : "";
        }
        const showComplaint = function(status) {
            if (complaintList.length > 0) {
                if (PENDING_STATUSES.indexOf(status) > -1) {
                    return complaintList.map((complaint, index) => {
                        if ((typeof(complaint.values.complaintStatus) === "undefined")
                            ? false
                            : (PENDING_STATUSES.indexOf(complaint.values.complaintStatus) > -1)) {
                            return showComplaintBody(complaint, index);
                        }
                    })
                } else {
                    return complaintList.map((complaint, index) => {
                        if ((typeof(complaint.values.complaintStatus) === "undefined")
                            ? false
                            : (COMPLETED_STATUSES.indexOf(complaint.values.complaintStatus) > -1)) {
                            return showComplaintBody(complaint, index);
                        }
                    })
                }
            }
        };
        const showComplaintBody = function(complaint, index) {
            return (
                <Link key={index} to={`/servicedescribe/${complaint.service_request_id}`}>
                    <div className="cont-bdr-mseva">
                        <h4 className="pull-left">{complaint.category}
                            <span>{formatDate(complaint.requested_datetime)}</span>
                        </h4>

                        <div className="clearfix"></div>
                        {renderImage(complaint.service_request_id)}
                        <dl>
                            <dt>{labels["pgr.lbl.complaintnumber"]} {complaint.service_request_id}</dt>
                            <dd>
                                {complaint.description}
                            </dd>
                        </dl>
                    </div>
                </Link>
            )
        }
        const renderImage = function(service_request_id) {
            if (images[service_request_id] && images[service_request_id].length) {
                return images[service_request_id].map((image, index) => {
                    return (<div key={index} className="complaint-img-wrap"><img src={API_ROOT + image} alt="" className="img-mseva"/></div>)
                })
            }
        }
        const countComplaintListByStatus = function(status) {
            if (complaintList.length > 0) {
                if (PENDING_STATUSES.indexOf(status) > -1) {
                    return commonComplaintCount(complaintList, PENDING_STATUSES)
                } else {
                    return commonComplaintCount(complaintList, COMPLETED_STATUSES)
                }
            }
        }
        const commonComplaintCount = function(complaintList, statuses) {
            let sum = 0;
            for (var i = 0; i < complaintList.length; i++) {
                if ((typeof(complaintList[i].values.complaintStatus) === "undefined")
                    ? false
                    : (statuses.indexOf(complaintList[i].values.complaintStatus) > -1)) {
                    sum++;
                }
            }
            return (
                <span>({sum})</span>
            );
        }
        return (
            <div >
                <h2 className="header-main-mseva">{labels["pgr.lbl.my.complaints"]}
                </h2>
                <div className="row">
                    <div className="col-sm-4">
                        <h3 className="header-sub-mseva">{labels["pgr.lbl.pending"]} {countComplaintListByStatus("REGISTERED")}
                        </h3>
                        {showComplaint("REGISTERED")}
                    </div>

                    <div className="col-sm-4">
                        <h3 className="header-sub-mseva">{labels["core.lbl.completed"]} {countComplaintListByStatus("COMPLETED")}
                        </h3>
                        {showComplaint("COMPLETED")}
                    </div>
                </div>
            </div>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Complaints);

// <Link to="/servicedescribe" className="option-mseva pull-right">
//     <i className="glyphicon glyphicon-option-vertical"></i>
// </Link>

// <a href="#">Request forwarded to Vishnu Pratap</a>
