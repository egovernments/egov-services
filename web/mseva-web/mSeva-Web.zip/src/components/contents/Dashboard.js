import React, { Component } from 'react';
import {Link} from 'react-router';
import dashboard from "../../images/dashboard.png";
import leftarrow from "../../images/left-arrow.png";
import rightarrow from "../../images/right-arrow.png";
import ourplatform01 from "../../images/our-platform-01.jpg";
import ourplatform02 from "../../images/our-platform-02.jpg";
import ourplatform03 from "../../images/our-platform-03.jpg";
import hoework01 from "../../images/how-it-work-01.jpg";
import hoework02 from "../../images/how-it-work-02.jpg";
import hoework03 from "../../images/how-it-work-03.jpg";
import hoework04 from "../../images/how-it-work-04.jpg";

import mobilepic from "../../images/mobile-pic.jpg";
import googleplayicon from "../../images/google-play-icon.jpg";
import {connect} from 'react-redux';
import {OpenModal, CloseModal} from '../../utils/modal';
import agent from '../../agent';
import {hashHistory, browserHistory} from 'react-router';


const mapStateToProps = state => ({
    labels: state.labels,
    token: state.common.token,
    route: state.common.route,
    complaintsLength: state.common.complaintsLength,
    trendingTypes: state.filecomplaint.trendingTypes
});


const mapDispatchToProps = dispatch => ({
  setRoute: (route) =>
    dispatch({type: 'SET_ROUTE', route}),
  getLength: () =>
    dispatch({type: 'GET_LENGTH', payload: agent.complaints.getAllComplaints()}) ,
  updateError: (error) =>
        dispatch({
            type: 'UPDATE_ERROR',
            error
        }),
  updateInitDatTypes: () => {
      dispatch({
        type: 'INIT_DAT_TYPES',
        payload: agent.complaints.getTrendingComplaintTypes()
      })
    },
  setLinkTo: (linkToService) => {
    dispatch({
      type: 'LINK_TO',
      linkToService
    })
  }
});


class Dashboard extends Component {

  constructor(props) {
    super(props);
    this.navigateToFileCom = this.navigateToFileCom.bind(this);
  }

  navigateToFileCom(e, type) {
    e.preventDefault();
    this.props.setLinkTo(type);
    if(this.props.token) {
      //Redirect to the route
      hashHistory.push('/filecomplaints');
    } else {
      this.props.setRoute("/filecomplaints");
      this.props.updateError("");
      OpenModal("loginModal");
    }
  }

  componentWillMount() {
    this.props.getLength();
    this.props.updateInitDatTypes();
  }

  render() {
    let {token, updateError, trendingTypes, labels}=this.props;
    let {navigateToFileCom} = this;
    const openLoginModal = (e, route) => {
      e.preventDefault();
      this.props.setRoute("/" + route);
      this.props.updateError("");
      OpenModal("loginModal");
    }

    const addComma = (num) => {
      return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    const renderTrendingComplaints = () => {
      return trendingTypes.map((item, ind) => {
        if(ind < 3) {
        return (
            <li key={ind}>
              <a href="" onClick={(e) => navigateToFileCom(e, item)}> {item.serviceName} </a>
            </li>
          )
        }
      })
    }

    const renderFileComplaintLink = function() {
      if(token) {
        return (
          <Link to="/filecomplaints">
            <span className="logoimg pic01"></span>
            <span>{labels["pgr.lbl.file.complaint"]}</span>
          </Link>
        )
      } else {
        return (
          <a href="" onClick={(e) => {openLoginModal(e, "filecomplaints")}}>
            <span className="logoimg pic01"></span>
            <span>{labels["pgr.lbl.file.complaint"]}</span>
          </a>
        )
      }
    }

    const renderMyComplaintLink = function() {
      if(token) {
        return (
          <Link to="/complaints">
            <span className="logoimg pic02"></span>
            <span>{labels["pgr.lbl.my.complaints"]}</span>
          </Link>
        )
      } else {
        return (
          <a href="" onClick={(e) => {openLoginModal(e, "complaints")}}>
            <span className="logoimg pic02"></span>
            <span>{labels["pgr.lbl.my.complaints"]}</span>
          </a>
        )
      }
    }

    const showRight = function()
    {
      return (
          <div className="link-left">
            <ul className="mseva-dash-blue-link">
              <li>
                {renderFileComplaintLink()}
              </li>
              <li>
                {renderMyComplaintLink()}
              </li>
            </ul>
          </div>
        )
    }

    return (
      <div>
        <h3 className="dashboard-heading">Help us make <strong>Kurnool </strong>better. <span>Let us know if there is a complaint we can solve for you.</span></h3>

          <div className="row dash-colm">
            <div className="col-sm-6 dash-colm-inner">
              <div id="carousel-example-generic" className="carousel slide mseva-dash-carousel" data-ride="carousel">
                <ol className="carousel-indicators">
                  <li data-target="#carousel-example-generic" data-slide-to="0" className="active"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                </ol>

                <div className="carousel-inner" role="listbox">
                  <div className="item active">

                    <div className="row">
                      <div className="testimonial-cont">
                        <div className="col-sm-6 mseva-pic">
                          <div className="mseva-prof-pic">
                            <img src={dashboard} alt=""/>
                          </div>
                          <h3>Sri CH Vijaya Mohan, IAS <span>Collector & District Magistrate. Kurnool</span></h3>
                        </div>
                        <div className="col-sm-6 testimonial">
                          <h3>Collector’s Message</h3>
                          <p>I solicit the kind co-operation of proud citizens of kurnool to give meaningful suggestions  for the common and larger goal of a peaceful and lovable Kurnool.</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="item">
                    <div className="row">
                      <div className="testimonial-cont">
                        <div className="col-sm-6 mseva-pic">
                          <div className="mseva-prof-pic">
                            <img src={dashboard} alt=""/>
                          </div>
                          <h3>Sri CH Vijaya Mohan, IAS <span>Collector & District Magistrate. Kurnool</span></h3>
                        </div>
                        <div className="col-sm-6 testimonial">

                          <h3>Collector’s Message</h3>
                          <p>I solicit the kind co-operation of proud citizens of kurnool to give meaningful suggestions  for the common and larger goal of a peaceful and lovable Kurnool.</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="item">
                    <div className="row">
                      <div className="testimonial-cont">
                        <div className="col-sm-6 mseva-pic">
                          <div className="mseva-prof-pic">
                            <img src={dashboard} alt=""/>
                          </div>
                          <h3>Sri CH Vijaya Mohan, IAS <span>Collector & District Magistrate. Kurnool</span></h3>
                        </div>
                        <div className="col-sm-6 testimonial">


                          <h3>Collector’s Message</h3>
                          <p>I solicit the kind co-operation of proud citizens of kurnool to give meaningful suggestions  for the common and larger goal of a peaceful and lovable Kurnool.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-sm-6 dash-colm-inner">
              <div className="dash-link-pan">
                {showRight()}
                <div className="link-right">
                  <h3>Trending complaints </h3>
                  <ul>
                    {renderTrendingComplaints()}
                  </ul>
                </div>
              </div>
            </div>

          </div>

          <div className="complaint-bg">
            <p><span>{addComma(this.props.complaintsLength)} </span>{labels["pgr.all.complaints"].toUpperCase()} {labels["core.msg.resolved"].toUpperCase()} </p>
          </div>

          <div className="platform">
            <a href="#" className="left-arrow"><img src={leftarrow} alt=""/></a>
            <a href="#" className="right-arrow"><img src={rightarrow} alt=""/></a>
            <h2>Our Platform. Your Voice </h2>
            <ul>
              <li>
                <span><img src={ourplatform01} alt=""/></span>
              </li>
              <li>
                <span><img src={ourplatform02} alt=""/></span>
              </li>
              <li>
                <span><img src={ourplatform03} alt=""/></span>
              </li>
            </ul>
            <p>&#34;It has helped me to connect to officials directly to get my complaint redressed in time. I like the ease of filing a complaint. I can also stay updated on the status of my application&#34;
                              <span>- Ramesh Kumar, Vijayanagar</span></p>
          </div>

          <div className="row">
            <div className="col-sm-7">
              <div className="dash-blue">
                <h3>How it works? </h3>
                <p>We have made connecting with us easier than ever before. Once you raise the complaint , we will assign it to the responsible officer. You can track the status of your complaint on our website under “My Complaints” till your complaint is resolved. </p>

                <ul className="work-flow-text">
                  <li className="arrow">&nbsp;</li>
                  <li>
                    <img src={hoework01}alt=""/>
                    <p>Raise a complaint </p>
                  </li>
                  <li>
                    <img src={hoework02} alt=""/>
                    <p>Connect to concerned officer </p>
                  </li>
                  <li>
                    <img src={hoework03} alt=""/>
                    <p>Track Status </p>
                  </li>
                  <li>
                    <img src={hoework04} alt=""/>
                    <p>Resolved </p>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-5">
              <div className="dash-blue">
                  <div className="row">
                    <div className="col-sm-6 text-center">
                      <img src={mobilepic} alt=""/>
                    </div>
                    <div className="col-sm-6">
                      <p>
                        <span className="blue">mSeva</span> is currently available on playstore.
                        <small>Download the app.</small>
                      </p>
                      <img src={googleplayicon} alt=""/>
                    </div>
                  </div>
              </div>
            </div>
          </div>

          <div className='toast' style={{display:"none"}}>{labels["core.account.created.successfully"]}</div>
  </div>
    );
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(Dashboard);
