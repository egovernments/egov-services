import React, { Component } from 'react';
import SimpleMap from '../common/GoogleMaps.js';
import Layer5 from '../../images/Layer5.jpg';
import agent from '../../agent.js';
import {connect} from 'react-redux';
import ImagePreview from '../common/ImagePreview.js';
import ListErrors from '../common/ListErrors';
import $ from 'jquery'
import {OpenModal, CloseModal} from '../../utils/modal'

//Autocomplete select
import Select from 'react-select';
import 'react-select/dist/react-select.css';

const mapStateToProps = state => ({
    labels: state.labels,
    complaintDat: state.filecomplaint.complaintDat,
    files: state.filecomplaint.files,
    trendingTypes: state.filecomplaint.trendingTypes,
    categories: state.filecomplaint.categories,
    types: state.filecomplaint.types,
    inProgress: state.filecomplaint.inProgress,
    errors: state.filecomplaint.errors,
    linkToService: state.filecomplaint.linkToService,
    currentUser: state.common.currentUser,
    token: state.common.token,
    auth: {
        ...state.auth
    }
});

const mapDispatchToProps = dispatch => ({
    handleChange: (e) => dispatch({
      type: 'FIELD_CHANGE', 
      key: e.target.id, 
      value: e.target.value
    }),
    handleUpload: (e) => {
      dispatch({type: 'FILE_UPLOAD', files: e.target.files})
    },
    submitCom: (e, complaintDat, currentUser) => {
       e.preventDefault();
       dispatch({
          type: 'ERROR',
          errors: ""
       })

      if(complaintDat.description.length < 10) {
          dispatch({
            type: 'ERROR',
            errors: "Description must be at least 10 characters long."
          })
      } else {
        //Set progress to true
        dispatch({
          type: 'PROGRESS',
          inProgress: true
        });

        //Post complaint
        let _complaintDat = Object.assign({}, complaintDat);
        _complaintDat.values.userId = currentUser.id;
        _complaintDat.first_name = currentUser.userName;
        _complaintDat.phone = currentUser.mobileNumber;
        _complaintDat.tenantId = agent.getTenantId();
        
        agent.complaints.postComplaint(_complaintDat).then(
          res => {
            dispatch({
              type: 'POST_COMPLAINT',
              payload: res
            });
          },
          error => {
            //Handle error
            dispatch({
              type: 'ERROR',
              errors: error
            })
            //Stop progress
            dispatch({
              type: 'PROGRESS',
              inProgress: false
            });
          }
        )
      }
    },
    handleClick: (key, value) => {
      document.getElementById(key).value = value;
      dispatch({type: 'FIELD_CHANGE', key, value})
    },
    handleMap: (places, field) => {
      //document.getElementById(field).value = places[0].formatted_address;
      dispatch({
        type: 'LOC_CHANGE', 
        //address: places[0].formatted_address, 
        lat: places[0].geometry.location.lat(), 
        lng: places[0].geometry.location.lng()
      });

      dispatch({
        type: 'CHANGE_ADDRESS',
        address_id: "403"
      });
    },
    updateComType: (e, groupId, service_code) => {
      if(groupId) {
        //document.getElementById("category").value = groupId;
        dispatch({
            type: 'FIELD_CHANGE',
            key: "category",
            value: groupId
          });
      }
      dispatch({
        type: 'COM_TYPE',
        payload: agent.complaints.getComplaintTypes((groupId || e.target.value))
      })
      if(service_code) {
          dispatch({
            type: 'FIELD_CHANGE',
            key: "service_code",
            value: service_code
          });
      }
    },
    updateInitDatTypes: () => {
      dispatch({
        type: 'INIT_DAT_TYPES',
        payload: agent.complaints.getTrendingComplaintTypes()
      })
    },
    updateInitDatCat: () => {
      dispatch({
        type: 'INIT_DAT_CAT',
        payload: agent.complaints.getCategories()
      })
    },
    setServiceRqstId: () => {
      dispatch({
        type: 'SR_ID'
      })
    },
    resetState: () => {
      dispatch({
        type: 'RESET_STATE'
      })
    },
    setProgress: inProgress =>
      dispatch({
        type: 'PROGRESS',
        inProgress
      }),
    handleError: errors => 
      dispatch({
        type: 'ERROR',
        errors
      }),
    fillAutoComplete: (addObject) => {
      dispatch({
        type: 'CHANGE_ADDRESS',
        address_id: addObject ? addObject.value : ""
      })
    },
    setLinkTo: (linkToService) => {
      dispatch({
        type: 'LINK_TO',
        linkToService
      })
    }
});

class FileComlanints extends Component {
  constructor() {
    super();
    this.uploadImages = this.uploadImages.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  componentDidMount() {
    this.props.updateInitDatTypes();
    this.props.updateInitDatCat();
    if(this.props.linkToService) {
      this.props.updateComType(null, this.props.linkToService.groupId, this.props.linkToService.serviceCode);
      this.props.setLinkTo("");
    } else {
      this.props.resetState();
    }
  }

  closeModal = () => {
      //document.getElementById("ackModal").className = "modal fade experience-modal";
      CloseModal("ackModal");
  }

  uploadImages() {
    if(this.props.files.length) {
      let counter = this.props.files.length;
      for(let i=0; i<this.props.files.length; i++) {
        if(!this.props.auth.errors){
          let formData = new FormData();
          formData.append("jurisdictionId", "ap.public");
          formData.append("module", "PGR");
          formData.append("tag", this.props.complaintDat.service_request_id);
          formData.append("file", this.props.files[i]);
          agent.complaints.uploadImage(formData).then(
            res => {
              counter--;
              if(counter == 0) {
                //Show modal
                //document.getElementById("ackModal").className = "modal fade experience-modal in show-ele";
                OpenModal("ackModal", ["experience-modal"]);
                document.getElementById("com-id-span").innerHTML = this.props.complaintDat.service_request_id;
                this.props.resetState();
              }
            },
            error => {
              //Handle error
              this.props.setProgress(false);
              this.props.handleError(error);
              this.props.handleChange({target:{id: "service_request_id", value: ""}});
            }
          )
        }
      }
    } else {
      //Show modal
      //document.getElementById("ackModal").className = "modal fade experience-modal in show-ele";
      OpenModal("ackModal", ["experience-modal"]);
      document.getElementById("com-id-span").innerHTML = this.props.complaintDat.service_request_id;
      //Reset state
      this.props.resetState();
    }
  }

  render() {
    let {token, handleChange, handleUpload, handleClick, handleMap, updateComType, submitCom, complaintDat, files, setSuccess, fillAutoComplete, labels} = this.props;
    
    //Check if- has service_request_id
    if(complaintDat.service_request_id) {
      this.uploadImages();
    }

    let getOptions = (input, callback) => {
      if(input)
        agent.complaints.getLocationByName(input).then(
          res => {
            let options = [];
            options = res.map((item) => {
              return {
                value: item.id,
                label: item.name
              };
            })
            callback(null, {options, caching: false});
          },
          error => {
            console.log(error);
          }
        )
    };

    let renderLi = () => {
      return (<ul id="trd-com" className="complaint-button">
        {this.props.trendingTypes.map((type, ind) => {
          return (<li key={ind}><button type="button" className="btn btn-primary" onClick={(e) => {updateComType(e, type.groupId, type.serviceCode)}}>{type.serviceName}</button></li>);
        })}</ul>
        )  
    };

    let renderCategoryOpt = () => {
      return (
        <select id="category" className="form-control" onChange={(e)=>{updateComType(e); handleChange(e)}} required value={complaintDat.category}>
          <option value="" defaultValue="selected">Select category</option>
          {
            this.props.categories.map((cat, ind) => {
              return (<option key={ind} value={cat.id}>{cat.description}</option>)
            })
          }
        </select>
      );
    };

    let renderTypeOpt = () => {
      return (
        <select id="service_code" className="form-control" onChange={(e)=>handleChange(e)} required value={complaintDat.service_code}>
          <option value="" defaultValue="selected">Select type</option>
          {
            this.props.types.map((type, ind) => {
              return (<option key={ind} value={type.serviceCode}>{type.serviceName}</option>)
            })
          }
        </select>
      );
    };

    let renderLastSection = () => {
      if(!token) {
        return (
          <div className="sectionBody">
              <div className="container">
                <div className="row">
                  <div className="col-sm-6">
                    <br/>
                      <div className="form-group">
                        <label htmlFor="first_name">{labels["core.lbl.add.name"]}*</label>
                        <input type="Text" value={complaintDat.first_name} className="form-control" id="first_name" placeholder="Enter name here" required onChange={(e)=>handleChange(e)}/>
                      </div>
                      <br/>
                      <div className="form-group">
                        <label htmlFor="phone">{labels["core.lbl.mobilenumber"]}*</label>
                        <input type="number" value={complaintDat.phone} className="form-control" id="phone" placeholder="Enter mobile no. here" required onChange={(e)=>handleChange(e)}/>
                      </div>

                      <div className="form-group">
                      <label htmlFor="email">{labels["core.lbl.email.compulsory"]}*</label>
                      <input type="email" value={complaintDat.email} required className="form-control" id="email" placeholder="Enter email here" onChange={(e)=>handleChange(e)}/>
                    </div>
                    <br/>
                </div>
              </div>
            </div>
          </div>
        )
      }
    }

    return (
      <div className="full-size">
        <form onSubmit={(e)=>submitCom(e, complaintDat, this.props.currentUser)} encType="multipart/form-data">
      <h2 className="header-main-mseva">{labels["pgr.lbl.file.complaint"]}</h2>

        <div className="sectionBody">
          <div className="text-center">

            <h4> Select from trending complaints </h4>
            
              {renderLi()}

            </div>
                <div className="div-or"><span>{labels["core.lbl.or"]}</span></div>
                <div>
                  <div className="row">
                  <div className="col-sm-6">

                  <div className="form-group">
                    <label htmlFor="category">{labels["pgr.lbl.complaint.category"]}*</label>
                    {renderCategoryOpt()}
                  </div>

                  <div className="form-group">
                    <label htmlFor="service_code">{labels["pgr.lbl.complainttype"]}*</label>
                    {renderTypeOpt()}
                  </div>

                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <label className="control-label">Select Photo</label>
                      <div>
                        <ImagePreview files={files}/>
                        <span className="btn btn-default btn-file" style={{position: "absolute", top: "160px"}}>
                          {labels["core.lbl.upload.image"]}
                          <input id="but" type="file" className="file" data-show-preview="false" accept="image/*" multiple onChange={(e)=>handleUpload(e)}/>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
      <div className="sectionBody">
        <div className="">
          <div className="row">
            <div className="col-sm-6">
                <div className="form-group">
                  <label htmlFor="address_id">{labels["core.lbl.location"]}*</label>
                  {/*<input type="Text" className="form-control location" id="address" placeholder="Select location" required onChange={(e)=>handleChange(e)} value={complaintDat.address}/>*/}
                  <Select.Async name="location"
                      className="auto-com-sel"
                      value={this.props.complaintDat.address_id}
                      loadOptions={getOptions}
                      onChange={fillAutoComplete}
                      isLoading="false"
                      placeholder="Location"
                      loadingPlaceholder="Location"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="address">{labels["core.lbl.landmark"]}</label>
                  <input type="text" className="form-control" id="address" placeholder={labels["core.lbl.landmark"]} onChange={(e)=>handleChange(e)}/>
                </div>
            </div>
            <div className="col-sm-1 map-or">{labels["core.lbl.or"]}</div>
            <div className="col-sm-5">
              <label>Select from the map</label>
              <div className="img_container">
                <div className="map-cont">
                  <SimpleMap markers={[]} handler={(places)=>{handleMap(places, "address")}}/>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <div className="sectionBody">
        <div className="row">
          <div className="col-sm-12">
              <div className="form-group">
                <label htmlFor="description">{labels["core.lbl.description"]}*</label>
                <textarea id="description" className="form-control" rows="5" placeholder={labels["core.lbl.description"]} required onChange={(e)=>handleChange(e)} value={complaintDat.description}></textarea>
              </div>
          </div>
        </div>
      </div>
      {renderLastSection()}
      <ListErrors errors={this.props.errors}/>
      <br/>
      <div className="submit-form">
        <button type="submit" className="btn btn-primary" disabled={this.props.inProgress}>
          {labels["core.lbl.submit"]}
        </button>
      </div>
      </form>
      <div className="modal fade experience-modal" id="ackModal" role="dialog">
            <div className="modal-dialog">

            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal" onClick={() => {this.closeModal()}}>{labels["core.lbl.close"]}</button>
                <h4 className="modal-title text-center">{labels["core.msg.acknowledgement"]}</h4>
              </div>
              <div className="modal-body">
                  {labels["pgr.msg.servicerequest.underprocess"]}
                  <br/><br/>
                  {labels["pgr.lbl.srn"]}
                  <br/><br/>
                  <span id="com-id-span"></span>
                  <br/><br/>
                  {labels["pgr.msg.future.reference"]}
              </div>
            </div>
          </div>
      </div>
</div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(FileComlanints);
