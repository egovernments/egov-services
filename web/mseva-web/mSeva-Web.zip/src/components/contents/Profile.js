import React, { Component } from 'react';
import profpic from '../../images/prof-pic.jpg'
import {connect} from 'react-redux';

const mapStateToProps= state =>({
  // userDetail: state.common.currentUser
  userDetail: {name:"muarli",mobileNumber:"7234324234",emailId:"asdasdas@gmail.com"}
})

const mapDispatchToProps =dispatch => ({

})

class Profile extends Component {
  render() {
    // console.log(this.props.userDetail);
    let {name,mobileNumber,emailId}=this.props.userDetail;
    return (
      <div>
	      <h2 className="header-main-mseva">My Profile</h2>
	      <div className="sectionBody">
		      <div className="row">
		      	<div className="col-sm-6">
		      		<div className="form-group">
		      			<label htmlFor="fname">Full Name* </label>
		      			<input type="text" className="form-control" value={typeof(name)==="undefined"?"":name} id="fname" placeholder="Enter Full Name" />
		      		</div>
		      		<div className="form-group">
	                    <label htmlFor="city">City* </label>
	                    <select className="form-control" id="city">
	                       <option>Bangalore</option>
	                    </select>
                  	</div>
                  	<div className="form-group">
		      			<label htmlFor="mnumber">Mobile Number* </label>
		      			<input type="text" className="form-control" id="mnumber" value={typeof(mobileNumber)==="undefined"?"":mobileNumber} placeholder="Enter Mobile Number" />
		      		</div>
		      	</div>
		        <div className="col-sm-6">
		        	<div className="form-group">
		        		<div>
			        		<span className="image-place-nobdr">
			                  <div><img src={profpic} alt="" className="img-mseva"/></div>
			                </span>
			                <span className="btn btn-default btn-file">
			                   Upload Image
			                  <input id="but" type="file" className="file" data-show-preview="false"/>
			                </span>
		                </div>
		        	</div>
		        </div>
		      </div>
	      </div>

	      <div className="sectionBody">
		      <div className="row">
		      	<div className="col-sm-6">
		      		<div className="form-group">
		      			<label htmlFor="aadhar">Aadhar Card Number* </label>
		      			<input type="text" className="form-control" id="aadhar" placeholder="Enter aadhar number" />
		      		</div>
		      	</div>
		      </div>

		      <label htmlFor="pass">Password </label>
		      <div className="row">
		      	<div className="col-sm-6">
		      		<div className="form-group">
		      			<input type="text" className="form-control" id="pass" placeholder="**********" />
		      		</div>
		      	</div>
		      	<div className="col-sm-6">
		      		<a href="#" className="link" data-target="#changepassModal" data-toggle="modal" data-dismiss="modal" >Change Password </a>
		      	</div>
		      </div>

		      <div className="row">
		      	<div className="col-sm-6">
		      		<div className="form-group">
		      			<label htmlFor="email">Email ID ( optional )</label>
		      			<input type="text" className="form-control" id="email" value={typeof(emailId)==="undefined"?"":emailId} placeholder="Enter email id" />
		      		</div>
		      	</div>
		      </div>
		  </div>


	          <div className="modal fade experience-modal" id="changepassModal" role="dialog">
	            <div className="modal-dialog">

	            <div className="modal-content">
	              <div className="modal-header">
	                <button type="button" className="close" data-dismiss="modal">Close</button>
	                <h4 className="modal-title text-center">Change Password</h4>
	              </div>
	              <div className="modal-body">
	                <div className="form-group">
		      			<label htmlFor="curpass">Current Password </label>
		      			<input type="text" className="form-control" id="curpass" placeholder="Enter your current password" />
		      		</div>
		      		<div className="form-group">
		      			<label htmlFor="newpass">New Password </label>
		      			<input type="text" className="form-control" id="newpass" placeholder="Enter new password" />
		      		</div>
		      		<div className="form-group">
		      			<label htmlFor="repass">Retype Password </label>
		      			<input type="text" className="form-control" id="repass" placeholder="Enter new password again" />
		      		</div>
		      		<div className="modal-button">
		      			<button type="button" className="btn btn-info" data-dismiss="modal">Save</button>
		      		</div>
	              </div>

	            </div>
	          </div>
	        </div>


      </div>
    );
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(Profile);
