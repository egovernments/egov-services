import React, { Component } from 'react';
import pic01 from '../../images/hist-pic-01.jpg';
import historypic from '../../images/history-pic.jpg';
import agent from '../../agent.js';
import {connect} from 'react-redux';
import ListErrors from '../common/ListErrors';
import {Link} from 'react-router';
import $ from 'jquery'

const PENDING_STATUSES = ["REGISTERED"]; //, "FORWARDED", "PROCESSING", "REJECTED" ,"NOTCOMPLETED", "REOPENED"
const COMPLETED_STATUSES = ["COMPLETED"]; //, "WITHDRAWN", "CLOSED"

const API_ROOT = window.location.origin;
const mapStateToProps = state => ({
  labels: state.labels,
  history: state.complaintdetails.history,
  current: state.complaintdetails.current,
  category: state.complaintdetails.category,
  images: state.complaintdetails.images,
  errors: state.complaintdetails.errors,
  text: state.complaintdetails.text,
  currentUser: state.common.currentUser,
  childLocationName: state.complaintdetails.childLocationName,
  locationName: state.complaintdetails.locationName,
  auth: {
        ...state.auth
  }
})

const mapDispatchToProps = dispatch => ({
    setComplaintDetails: payload => dispatch({type: "COMPLAINT_DETAILS", payload}),
    setComplaintHistory: payload => dispatch({type: "COMPLAINT_HISTORY", payload}),
    setCategory: category => dispatch({type: 'CATEGORY', category}),
    putComments: e => dispatch({type: 'PUT_COMMENT', comments: e.target.value}),
    setLocName: locationName => dispatch({type: 'SET_LOC_NAME', locationName}),
    setChildLocName: childLocationName => dispatch({type: 'SET_C_LOC_NAME', childLocationName}),
    putStarRating: starRating => {
       if(starRating < 3) {
         dispatch({type: 'CHANGE_TEXT', text: "bad"});
       } else {
         dispatch({type: 'CHANGE_TEXT', text: "good"});
       }

       dispatch({type: 'PUT_RATING', starRating})
    },
    updateComplaint: (current, currentUser) => {
     let ServiceRequest = Object.assign({}, current);
      ServiceRequest.values.status = "COMPLETED";
      ServiceRequest.values.userId = currentUser.id;
      //ServiceRequest.values.locationId = ServiceRequest.values.locationId;
      //delete ServiceRequest.values.locationId;
      ServiceRequest.tenantId = agent.getTenantId();
      agent.complaints.updateComplaint(ServiceRequest).then(
        res => {
          if(res.service_requests && res.service_requests[0] && res.service_requests[0].values && res.service_requests[0].values) {
            res.service_requests[0].values.complaintStatus = "COMPLETED";
          }
          $('#success-toast').fadeIn(400).delay(4000).fadeOut(400);
          dispatch({type: "COMPLAINT_DETAILS", payload: res});
          dispatch({type: "COMPLAINT_HISTORY", payload: agent.complaints.getComplaintHistory(current.values.stateId)});
        },
        error => {
          //Handle error
          console.log(error);
        }
      )
      //return dispatch({type: "UPDATE_COMPLAINT"});
    },
    setImages: (payload) => dispatch({type: 'SET_IMAGES', payload}),
    handleError: (errors) => dispatch({type: 'ERROR', errors})
})

class ServiceDescribe extends Component {

  componentDidMount() {
    //Fetch complaint and its history
    agent.complaints.getComplaintDetails(this.props.params.id).then(
      res => {
        agent.complaints.getAllComplaintTypes().then(
          res1 => {
            this.props.setComplaintDetails(res);
            //Get location
            if(res.service_requests && res.service_requests[0] && res.service_requests[0].values && res.service_requests[0].values.locationId) {
              agent.complaints.getLocationById(res.service_requests[0].values.childLocationId).then(
                res2 => {
                  if(res2.Boundary && res2.Boundary && res2.Boundary[0] && res2.Boundary[0].name) {
                    //res.service_requests[0].values.childLocationName = res2.Boundary[0].name;
                    this.props.setChildLocName(res2.Boundary[0].name);
                  }              
                },
                error => {
                  //Handle error
                  console.log(error);
                }
              )
            }
            
            if(res.service_requests && res.service_requests[0] && res.service_requests[0].values && res.service_requests[0].values.childLocationId){

              agent.complaints.getLocationById(res.service_requests[0].values.locationId).then(
                res3 => {
                  if(res3.Boundary && res3.Boundary && res3.Boundary[0] && res3.Boundary[0].name) {
                      //res.service_requests[0].values.locationName = res3.Boundary[0].name;
                      this.props.setLocName(res3.Boundary[0].name);
                  }
                },
                error => {
                  //Handle error
                  console.log(error);
                })    
            } 
            //Get complaint history
            this.props.setComplaintHistory(agent.complaints.getComplaintHistory(res.service_requests[0].values.stateId));
            if(res && res.service_requests[0] && res1.length) {
              for(let i=0;i<res1.length;i++) {
                if(res.service_requests[0].service_code == res1[i].serviceCode) {
                  return this.props.setCategory(res1[i].groups);
                }
              }
            }
          },
          error => {
            //Handle error
            this.props.handleError(error);
          }
        )
      },
      error => {
        //Handle error
        this.props.handleError(error);
      }
    )

    //Fetch images if any
    this.props.setImages(agent.complaints.getFiles(this.props.params.id));
  }

  render() {
    let {current, history, auth, images, text, childLocationName, locationName, labels} = this.props;
    let showResolvedCurrentBtn = () => {
      return (current && current.values && PENDING_STATUSES.indexOf(current.values.complaintStatus) > -1) ? (<button type="button" className="btn btn-primary" data-toggle="modal" data-target="#myModal">{labels["core.msg.mark.resolved"]}</button>) : (<button type="button" className="btn btn-success" style={{cursor: "pointer"}}>{labels["core.msg.resolved"]}</button>);
    };
    const getDate = () => {
      return current && current.requested_datetime ? current.requested_datetime.split(" ")[0] : "";
    };
    const getDept = () => {
      if(history.length) {
        let last = history.length-1;
        return history[last].values && history[last].values.department && history[last].values.department.values && history[last].values.department.values[0] ? history[last].values.department.values[0].name : "";
      }
    };
    const titleCase = function(status) {
      if(status) {
        return status.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + status.substr(1).toLowerCase();});

      }
    }

    const formatDate = (date) => {
      return date ? date.split(" ")[0] : "";
    }
    let renderImage = () => {
      return (
        images.map((image, ind) => {
          return (<li key={ind}><img src={API_ROOT + image.url} alt="" /></li>)
        })
      )
    };
    
    let renderCheckbox = () => {
      if(text) {
        return (
          <div>
            <p>What was {text}?</p>
                            <div className="checkbox">
                              <label>
                                <div className="imageCheckbox">
                                  <input type="checkbox" id="service" name="service" value="1"/>
                                  <label htmlFor="service"></label>
                                  <span>Service</span>
                                  <div className="clearfix"></div>
                                </div>
                              </label>
                            </div>
                            <div className="checkbox">
                              <label>
                                <div className="imageCheckbox">
                                  <input type="checkbox" id="resolvetime" name="resolvetime" value="2"/>
                                  <label htmlFor="resolvetime"></label>
                                  <span>Resolve Time</span>
                                  <div className="clearfix"></div>
                                </div>
                              </label>
                            </div>
                            <div className="checkbox">
                              <label>
                                <div className="imageCheckbox">
                                  <input type="checkbox" id="work" name="work" value="3"/>
                                  <label htmlFor="work"></label>
                                  <span>Work</span>
                                  <div className="clearfix"></div>
                                </div>
                              </label>
                            </div>
                            <div className="checkbox">
                              <label>
                                <div className="imageCheckbox">
                                  <input type="checkbox" id="others" name="others" value="4"/>
                                  <label htmlFor="others"></label>
                                  <span>Other</span>
                                  <div className="clearfix"></div>
                                </div>
                              </label>
                            </div>
          </div>
        )
      }
    };

    let renderHistory = () => {
      if(history.length) {
        return (
          history.map((item, ind) => {
            return (
              <li className={(current && current.values && PENDING_STATUSES.indexOf(current.values.complaintStatus) == -1 && ind == (history.length-1)) ? "hist-completed" : "hist-reset"} key={ind}>
                <h5>{titleCase(item.status)}
                <span>{formatDate(item.created_Date)} </span></h5>
                <div className="history-cont">
                  <h6>{labels["pgr.lbl.updatedby"]} {item.sender_name}</h6>
                  <p> {item.comments} </p>
                </div>
              </li>
            )
          })
        )
      } else {
        return "";
      }
    };

    return (
    <div>
      <h2 className="header-main-mseva">Complaint Details <Link to={`/complaints`}>Back</Link></h2>

      <ListErrors errors={this.props.errors}/>

      <div className="row">
        <div className="col-sm-8">
          <div className="sectionBody">
            <div className="row comp-det">
              <div className="col-sm-6">
                <h3>Complaint Details</h3>
              </div>
              <div className="col-sm-6">
                  {showResolvedCurrentBtn()}
              </div>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>{labels["pgr.lbl.complaintnumber"]}</label>
              </div>
              <div className="col-sm-6">
                  <label className="bold">{this.props.params.id}</label>
              </div>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>Filed By</label>
              </div>
              <div className="col-sm-6">
                <label className="bold">{current.first_name}</label>
              </div>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>{labels["pgr.lbl.complaint.category"]}</label>
              </div>
              <div className="col-sm-6">
                  <label className="bold">{this.props.category}</label>
              </div>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>{labels["pgr.lbl.complainttype"]}</label>
              </div>
              <div className="col-sm-6">
                <label className="bold">{current.service_name}</label>
              </div>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>{labels["core.lbl.location"]}</label>
              </div>
              <div className="col-sm-6">
                <label className="bold"><i className="glyphicon glyphicon-map-marker"></i> {childLocationName || ""} - {locationName || ""} </label>
              </div>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>{labels["core.lbl.landmark"]}</label>
              </div>
              <div className="col-sm-6">
                  <label className="bold">{current.address}</label>
              </div>
            </div>


            <div className="comp-det comp-det">
              <label>Images</label>
              <ul className="hist-image">
                {renderImage()}
              </ul>
            </div>

            <div className="row comp-det">
              <div className="col-sm-6">
                <label>{labels["core.lbl.description"]}</label>
              </div>
              <div className="col-sm-6">
                  <label className="bold">{current.description} </label>
              </div>
            </div>

          </div>
        </div>




        <div className="col-sm-4">
          <div className="comp-history">
            <h4>{labels["core.lbl.history"]} : {labels["pgr.lbl.complaintnumber"]} {this.props.params.id} </h4>
            <ul>
              <li className="hist-text">
                <h5>Complaint filed <span>{getDate()}</span></h5>
              </li>
              <li className="hist-flyer">
                <h5>Complaint sent to {history.length ? history[history.length-1].assignee : "-"}
                <span>Dept : {getDept() || "-"} </span>
                <span>{history.length ? formatDate(history[history.length-1].created_Date) : ""} </span>
                </h5>
              </li>
              {renderHistory()}
            </ul>
            
            {showResolvedCurrentBtn()}

            </div>
          </div>
        </div>


        <div className="">
          <div className="modal fade experience-modal" id="myModal" role="dialog">
            <div className="modal-dialog">

            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal">{labels["core.lbl.close"]}</button>
                <h4 className="modal-title text-center">Rate Your Experience</h4>
              </div>
              <div className="modal-body">
                            <div >
                            <div>
                              <div>
                              <div className="rating">
                                <input type="radio" id="star5" name="rating" value="5"/><label className="full" htmlFor="star5" onClick={() => {this.props.putStarRating(5)}}></label>

                                <input type="radio" id="star4" name="rating" value="4" /><label className="full" htmlFor="star4" onClick={() => {this.props.putStarRating(4)}}></label>

                                <input type="radio" id="star3" name="rating" value="3" /><label className="full" htmlFor="star3" onClick={() => {this.props.putStarRating(3)}}></label>

                                <input type="radio" id="star2" name="rating" value="2" /><label className="full" htmlFor="star2" onClick={() => {this.props.putStarRating(2)}}></label>

                                <input type="radio" id="star1" name="rating" value="1" /><label className="full" htmlFor="star1" onClick={() => {this.props.putStarRating(1)}}></label>
                              </div>
                              <div className="clearfix"></div>


                            <form className="text-center">
                              {renderCheckbox()}
                              <textarea id="comment" placeholder={labels["core.lbl.comments"]} onChange={(e) => {this.props.putComments(e)}}></textarea>
                            </form>


                        </div>
                      </div>

                  </div>
                  <ListErrors errors={this.props.errors}/>
                  <div className="modal-button">
                    <button type="button" className="btn btn-info" data-dismiss="modal" onClick={() => this.props.updateComplaint(this.props.current, this.props.currentUser)}>{labels["core.lbl.submit"]}</button>
                  </div>
              </div>

            </div>
          </div>
        </div>
    </div>
    <div id="success-toast" className='toast' style={{display:"none"}}>Complaint closed successfully.</div>
  </div>);
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ServiceDescribe);
