

import agent from './agent';

const promiseMiddleware = store => next => action => {
  if (isPromise(action.payload)) {
    store.dispatch({ type: 'ASYNC_START', subtype: action.type });

    const currentView = store.getState().viewChangeCounter;
    const skipTracking = action.skipTracking;

    action.payload.then(
      res => {
        const currentState = store.getState()
        if (!skipTracking && currentState.viewChangeCounter !== currentView) {
          return
        }
        // console.log('RESULT', res);
        action.payload = res;
        store.dispatch({ type: 'ASYNC_END', promise: action.payload });
        store.dispatch(action);
      },
      error => {
        const currentState = store.getState()
        if (!skipTracking && currentState.viewChangeCounter !== currentView) {
          return
        }
        // console.log('ERROR', error);
        action.error = true;
        action.payload = error.response.body;
        if (!action.skipTracking) {
          store.dispatch({ type: 'ASYNC_END', promise: action.payload });
        }
        store.dispatch(action);
      }
    );

    return;
  }

  next(action);
};

const localStorageMiddleware = store => next => action => {
  if (action.type === 'REGISTER' || action.type === 'LOGIN') {
    if (!action.error) {
      window.localStorage.setItem('jwt', action.payload.access_token);
      window.localStorage.setItem('userId', action.payload.UserRequest.id);
      window.localStorage.setItem('type', action.payload.UserRequest.type);
      window.localStorage.setItem('tenantId', action.payload.UserRequest.tenantId);
      window.localStorage.setItem('currentUser', JSON.stringify(action.payload.UserRequest));
      agent.setToken(action.payload.access_token);
      agent.setUserId(action.payload.UserRequest.id);
      agent.setType(action.payload.UserRequest.type);

    }
  } else if (action.type === 'LOGOUT') {
    window.localStorage.setItem('jwt', '');
    window.localStorage.setItem('userId', '');
    window.localStorage.setItem('type', '');
    window.localStorage.setItem('currentUser', '{}');
    agent.setToken(null);
    agent.setUserId(null);
    agent.setType(null);
  }

  next(action);
};

function isPromise(v) {
  return v && typeof v.then === 'function';
}


export { promiseMiddleware, localStorageMiddleware }
