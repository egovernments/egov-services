
import labels from './reducers/labels';
import auth from './reducers/auth';
import common from './reducers/common';
import complaint from './reducers/complaint';
import filecomplaint from './reducers/filecomplaint';
import complaintdetails from './reducers/complaintdetails';
import form from './reducers/form';
import { combineReducers } from 'redux';

export default combineReducers({
  labels,
  auth,
  common,
  complaint,
  filecomplaint,
  form,
  complaintdetails
});
