const defaultState = {
  complaint: {},
  complaintList: [],
  images: {}
};

export default (state = defaultState, action) => {
  switch (action.type) {
    case 'ADD_COMPLAINT_LIST':
      return {
        ...state,
        complaintList: (action.payload && action.payload.service_requests) ? action.payload.service_requests : []
      };
    case 'ADD_IMAGES':
      return {
        ...state,
        images: action.images
      }
  }

  return state;
};
