const defaultState = {
    history: [],
    current: {},
    category: "",
    images: [],
    errors: "",
    text: "",
    locationName: "",
    childLocationName: ""
};

export default (state = defaultState, action) => {
    switch(action.type) {
        case 'COMPLAINT_DETAILS': 
            return {
                ...state,
                current: (action.payload && action.payload.service_requests) ? action.payload.service_requests[0] : {}
            };
        case 'COMPLAINT_HISTORY':
            return {
                ...state,
                history: (action.payload) || []
            };
        case 'UPDATE_COMPLAINT':
            return {
                ...state
            };
        case 'CATEGORY':
            return {
                ...state,
                category: action.category
            };
        case 'SET_IMAGES':
            return {
                ...state,
                images: action.payload ? action.payload.files : []
            }
        case 'ERROR':
            return {
                ...state,
                errors: action.errors+''
            }
        case 'PUT_COMMENT':
            return {
                ...state,
                current: {
                    ...state.current,
                    values: {
                        ...state.current.values,
                        approvalComments: action.comments
                    }
                }
            }
        case 'PUT_RATING':
            return {
                ...state,
                current: {
                    ...state.current,
                    values: {
                        ...state.current.values,
                        starRating: action.rating
                    }
                }
            }
        case 'CHANGE_TEXT':
            return {
                ...state,
                text: action.text
            }
        case 'SET_LOC_NAME':
            return {
                ...state,
                locationName: action.locationName
            }
        case 'SET_C_LOC_NAME':
            return {
                ...state,
                childLocationName: action.childLocationName
            }
        default: 
            return state;
    }
}