const defaultState = {
    complaintDat: {
        category: '',
        service_code: '',
        address: '',
        landmark: '',
        description: '',
        first_name: '',
        phone: '',
        email: '',
        lat: '0',
        lng: '0',
        address_id: "",
        tenantId:"ap.public",
        status: true,
        values: {
            "receivingMode":"Website",
            "receivingCenter":"",
            "status":"REGISTERED",
            "complainantAddress":""
        },
        service_request_id: ''
    },
    files: [],
    trendingTypes: [],
    categories: [],
    types: [],
    inProgress: false,
    errors: "",
    linkTo: false,
    linkToService: ""
};

export default (state = defaultState, action) => {
    switch(action.type) {
        case 'FIELD_CHANGE':
            return {
                ...state,
                complaintDat: {
                    ...state.complaintDat,
                    [action.key]: action.value
                }
            };
        case 'FILE_UPLOAD':
            return {
                ...state,
                files: action.files
            };
        case 'POST_COMPLAINT':
            return {
                ...state,
                complaintDat: {
                    ...state.complaintDat,
                    service_request_id: action.payload.service_requests[0].service_request_id
                }
            }
        case 'LOC_CHANGE':
            return {
                ...state,
                complaintDat: {
                    ...state.complaintDat,
                    address: action.address,
                    lat: action.lat,
                    lng: action.lng
                }
            }
        case 'COM_TYPE':
            return {
                ...state,
                types: action.payload
            }
        case 'INIT_DAT_TYPES':
            return {
                ...state,
                trendingTypes: action.payload
            }
        case 'INIT_DAT_CAT': 
            return {
                ...state,
                categories: action.payload
            }
        case 'SR_ID':
            return {
                ...state,
                complaintDat: {
                    ...state.complaintDat,
                    service_request_id: ''
                }
            }
        case 'RESET_STATE':
            return {
                ...defaultState,
                trendingTypes: state.trendingTypes,
                categories: state.categories,
                types: state.types
            }
        case 'PROGRESS':
            return {
                ...state,
                inProgress: action.inProgress
            }
        case 'ERROR':
            return {
                ...state,
                errors: action.errors + ""
            }
        case 'CHANGE_ADDRESS':
            return {
                ...state,
                complaintDat: {
                    ...state.complaintDat,
                    address_id: action.address_id
                }
            }
        case 'LINK_TO':
            return {
                ...state,
                linkToService: action.linkToService
            }
    }

    return state;
}