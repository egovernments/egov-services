import React from 'react';
import {Route, Router, IndexRoute,IndexRedirect, hashHistory,browserHistory} from 'react-router';
import App from "./components/App";
import Main from "./components/Main";
import history from 'history';
import Dashboard from "./components/contents/Dashboard";
import Complaints from "./components/contents/Complaints";
import FileComplaints from "./components/contents/FileComplaints";
import SevicesDescribe from "./components/contents/SevicesDescribe";
import Profile from "./components/contents/Profile";


export default(
  <Router history={hashHistory}>
      <Route path="/" component={App}>
              <IndexRedirect to="/main" />
              <Route path="/main" component={Main}>
                  <IndexRoute component={Dashboard}/>
                  <Route path="/complaints" component={Complaints}/>
                  <Route path="/filecomplaints" component={FileComplaints}/>
                  <Route path="/servicedescribe/:id" component={SevicesDescribe}/>
                  <Route path="/profile" component={Profile}/>
              </Route>
      </Route>
  </Router>
);
