import $ from 'jquery';
const OpenModal = (modalId, classes) => {
    if(document.getElementById(modalId)) {
        document.getElementById(modalId).classList.add("in", "show-ele");
        $("#" + modalId).on('click', function(e){
            if(/modal /.test(e.target.className)) {
                CloseModal(modalId);
            }
        })
        if (classes && classes.constructor == Array && classes.length) {
            classes.map((cls) => {
                document.getElementById(modalId).classList.add(cls);
            })
        }
        let div = document.createElement('div');
        div.className = "modal-backdrop fade in";
        div.id = "modal-backdrop-div";
        document.body.appendChild(div);
        document.body.style.paddingRight = "17px";
        document.body.classList.add('modal-open');
    }
}

const CloseModal = (modalId) => {
    if(document.getElementById(modalId)) {
        document.getElementById(modalId).classList.remove("in", "show-ele");
        document.getElementById(modalId).style.display = "none";
        let div = document.getElementById('modal-backdrop-div');
        if (div) {
            div.parentNode.removeChild(div);
        }
        let div2 = document.getElementsByClassName("modal-backdrop") ? document.getElementsByClassName("modal-backdrop")[0] : "";
        if(div2) {
            div2.parentNode.removeChild(div2);
        }
        document.body.classList.remove('modal-open', 'pad-r-body');
        document.body.style = "";
    }
}

export {OpenModal, CloseModal};